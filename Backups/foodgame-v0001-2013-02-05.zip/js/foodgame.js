﻿$(document).ready(function () {
    //Background Canvas
    var bg_canvas = $("#bg_C")[0];
    var bg_ctx = bg_canvas.getContext("2d");

    //Ant Canvas
    var a_canvas = $("#a_C")[0];
    var a_ctx = a_canvas.getContext("2d");

    //Food Canvas
    var f_canvas = $("#f_C")[0];
    var f_ctx = f_canvas.getContext("2d");

    //Ant Hill Canvas
    var h_canvas = $("#h_C")[0];
    var h_ctx = h_canvas.getContext("2d");

    //Pause Screen Canvas
    var p_canvas = $("#p_C")[0];
    var p_ctx = h_canvas.getContext("2d");

    var w = $("#bg_C").width(); // game screen width
    var h = $("#bg_C").height(); // game screen height

    //Global Variables
    var isPlaying = false;
    var requestAnimationFrame = window.requestAnimationFrame ||
                                window.webkitRequestAnimationFrame ||
                                window.mozRequestAnimationFrame ||
                                window.msRequestAnimationFrame ||
                                window.oRequestAnimationFrame;

    var isUpKey = false;
    var isDownKey = false;
    var isRightKey = false;
    var isLeftKey = false;

    var o_font = h_ctx.font;

    var gametime; 
    var count = 0;

    function GenericAnt (x, y, size, speed, carry, inEnemyTerr, 
			 gavePoints, color) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.speed = speed;
        this.carry = carry;
        this.inEnemyTerr = inEnemyTerr;
        this.gavePoints = gavePoints;
        this.color = color; 
    }
    GenericAnt.prototype.action = function () {console.log("bad")}
    GenericAnt.prototype.draw = function () {
        draw_Square(this.x, this.y, this.size, this.color, a_ctx);
        a_ctx.fillStyle = "black";
        var text = "F: " + this.carry;
        a_ctx.fillText(text, this.x -(this.size/2+2), this.y-this.size/2+2);
    }

    EnemyAnt.prototype = new GenericAnt();
    function EnemyAnt() {
        this.x = Math.round(Math.random()*400);
        this.y = Math.round(Math.random()*400);
        this.size = 8;
        this.speed = 5;
        this.carry = 0;
        this.inEnemyTerr = false;
        this.gavePoints = false;
        this.color="red";
    }

    Ant.prototype = new GenericAnt();
    function Ant() {
        this.x = Math.round(w-(w/4));
        this.y = Math.round(h-(h/4));
        this.size = 8;
        this.speed = 5;
        this.carry = 0;
        this.inEnemyTerr = false;
        this.gavePoints = false;
        this.color = "blue";
    }

    //    var ant = new Ant();
 
    // Food object
    function food (x, y, size, score) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.score = score;
//        this.action = function () {};
//        this.draw = function() {draw_food();}
        }

        //Ant Hill function
        var p_antHill = {
            x: w-30,
            y: h-30,
            size: 60,
            score: 0,
            action: function() {},
        };
        var e_antHill = {
            x: 30,
            y: 30,
            size: 60,
            score: 0,
            action: function() {},
        };

        var object_arr = new Array();
	
        var enemy_arr = new Array();
        var food_arr = new Array();

        //This function will set up the ant and food
        //This function will call draw on the animation loop

        function init() {
        
            clearInterval(gametime);
            drawbg();
            object_arr.push(new Ant());
            for (var i = 0; i < 5; i++) {
                object_arr.push(create_food());
            }
            for (var i = 0; i < 1; i++) {
                object_arr.push(createEnemy());
            }
            console.log("The Game has started");
            console.log("Ant is created");
            score = 0;

            gameLoop();


            console.log("Game should be drawn now.");
            return;
        }
    
        init();

        function gameLoop() {
            if(!isPlaying){
                pause();
                requestAnimationFrame(gameLoop);
            }
            if (isPlaying) {
                update();
                paint();
                requestAnimationFrame(gameLoop);
            }
       
        }

        function pause(){
            p_ctx.fillStyle="black";
            p_ctx.globalAlpha = 0.01;
            p_ctx.fillRect(0,0,w,h);
            p_ctx.globalAlpha = 1;
            p_ctx.fillStyle="White"
            p_ctx.font = 'bold 20px helvetica';
            p_ctx.fillText("Press 'p' to continue.", w/2 - 100, h/2);
            p_ctx.font = o_font;
        }

        function startTime(){
            gametime = setInterval(counter, 1000);
        }

        function stopTime(){
            clearInterval(gametime);
            gametime = null;
        }

        function counter() {
            if (count == 60) {
                isPlaying = false;
            }
            else {
                count++;
            }
        }

        function update() {
            //        ant.action();
            for (var i = 0; i < object_arr.length; i++) {
                object_arr[i].action();
            }
        }

        function paint() {
            a_ctx.clearRect(0, 0, w, h);
            f_ctx.clearRect(0, 0, w, h);
            h_ctx.clearRect(0, 0, w, h);
            bg_ctx.clearRect(0, 0, w, h);

            draw_antHill(p_antHill.x-2, p_antHill.y-2, p_antHill.size, "blue", 0);
            h_ctx.font = 'bold 15px helvetica';
            h_ctx.fillText("BLUE", p_antHill.x-20, p_antHill.y);
            h_ctx.font = o_font;
        
            draw_antHill(e_antHill.x+2, e_antHill.y+2, e_antHill.size, "red", 1);
            h_ctx.font = 'bold 15px helvetica';
            h_ctx.fillText("RED", e_antHill.x-15, e_antHill.y);
            h_ctx.font = o_font;

            for (var i = 0; i < object_arr.length; i++) {
                object_arr[i].draw();
            }
        
            //console.log("end draw");
            drawbg();
            h_ctx.font = o_font;
            return;
        }

        function drawbg() {
            bg_ctx.fillStyle = "white";
            bg_ctx.fillRect(0, 0, w, h);
            bg_ctx.strokeStyle = "black";
            bg_ctx.strokeRect(0, 0, w, h);

            var text = "Time Remaining: " + (60-count);
            h_ctx.font = 'bold 15px helvetica';
            h_ctx.fillText(text, 5, h-5);
        }

        function draw_Square( x, y, size, a_color, layer) {
            var center = Math.round( size / 2);
            layer.fillStyle = a_color;
            layer.fillRect(x - center, y - center, size, size);
            layer.strokeStyle = "black";
            layer.strokeRect(x - center, y - center, size, size);
        }

        // antControl()
        Ant.prototype.action = function () { 

            if (isUpKey && this.y >= 5) {
                this.y -= this.speed;
            }
            if (isDownKey && this.y <= h - 5) {
                this.y += this.speed;
            }
            if (isLeftKey && this.x >= 5) {
                this.x -= this.speed;
            }
            if (isRightKey && this.x <= w - 5) {
                this.x += this.speed;
            }

//            checkFoodCollision(this);
//            checkHillCollision(this);
//            checkAntCollision(this);

            if (this.carry == 0) {
                this.speed = 5;
            }
            if (this.speed >= 0.5 ) {
                this.speed = (5 - this.carry / 100);
            }
            if (this.speed < 0.5 ) {
                this.speed = 0.5;
            }

            for (var i = 0; i < object_arr.length; i++) {
                var curO = object_arr[i];
                var radius = curO.size / 2 + 2;
                if (this.x > curO.x - radius && this.x < curO.x + radius &&
                    this.y > curO.y - radius && this.y < curO.y + radius) {
                    if (curO instanceof food) {
                        this.carry += Math.floor(curO.score);
                        object_arr.splice(i, 1);
                        object_arr.push(create_food());
                    } else if (curO instanceof EnemyAnt) {
                        var avg = Math.floor((this.carry + curO.carry) / 2);
                        this.carry = avg;
                        curO.carry = avg;
                    }
                }
            }
            var radius = p_antHill.size / 2 + 2;
            if (this.x > p_antHill.x - radius && this.x < p_antHill.x + radius &&
                this.y > p_antHill.y - radius && this.y < p_antHill.y + radius) {
                p_antHill.score += this.carry;
                this.carry = 0;
            }

            radius = e_antHill.size / 2 + 2;
            if (this.x > e_antHill.x - radius && this.x < e_antHill.x + radius &&
                this.y > e_antHill.y - radius && this.y < e_antHill.y + radius) {
                this.inEnemyTerr = true;
                if (!this.gavePoints) {
                    this.gavePoints = true;
                    e_antHill.score += Math.round((this.carry / 4) * 3);
                    this.carry = Math.round(this.carry / 4);
                }
            }
            else {
                this.inEnemyTerr = false;
                this.gavePoints = false;
            }
        }
/*
        function checkFoodCollision(ant) {
            for (var i = 0; i < food_arr.length; i++) {
                var curF = food_arr[i];
                var radius = curF.size/2 + 2;
                if (ant.x > curF.x - radius && ant.x < curF.x + radius &&
                    ant.y > curF.y - radius && ant.y < curF.y + radius) {
                    ant.carry += Math.floor(curF.score);
                    food_arr.splice(i, 1);
                    food_arr.push(create_food());
                }
            }
        }

        function checkHillCollision(ant) {
            var radius = p_antHill.size / 2 + 2;
            if (ant.x > p_antHill.x - radius && ant.x < p_antHill.x + radius &&
                ant.y > p_antHill.y - radius && ant.y < p_antHill.y + radius) {
                p_antHill.score += ant.carry;
                ant.carry = 0;
            }
        
            radius = e_antHill.size / 2 + 2;
            if (ant.x > e_antHill.x - radius && ant.x < e_antHill.x + radius &&
                ant.y > e_antHill.y - radius && ant.y < e_antHill.y + radius) {
                ant.inEnemyTerr = true;
                if (!ant.gavePoints) {
                    ant.gavePoints = true;
                    e_antHill.score += Math.round((ant.carry / 4) * 3);
                    ant.carry = Math.round(ant.carry / 4);
                }
            }
            else{
                ant.inEnemyTerr = false;
                ant.gavePoints = false;
            }
        }

        function checkAntCollision(ant) {
            for (var i = 0; i < enemy_arr.length; i++) {
                var curE = enemy_arr[i];
                var radius = curE.size / 2 + 2;
                if (ant.x > curE.x - radius && ant.x < curE.x + radius &&
                    ant.y > curE.y - radius && ant.y < curE.y + radius) {
                    var avg = Math.floor((ant.carry + curE.carry) / 2);
                    ant.carry = avg;
                    curE.carry = avg;
                }
            }
        }
*/
        //Enemy Ant functions
        function createEnemy() {
            return (new EnemyAnt());
        }
        // enemyAI
        EnemyAnt.prototype.action = function () {
            curE = this; // enemyAnt object
            var curF;

            var hasTarget = false;
            var x = 0;
            var y = 0;
            var dist = 1000;
            var ratio = 0;

            for (var i = 0; i < object_arr.length; i++) {
                curF = object_arr[i];
                if (curF instanceof food) {
                    var distX = curF.x - curE.x;
                    var distY = curF.y - curE.y;
                    distX = distX * distX;
                    distY = distY * distY;
                    var distF = Math.sqrt(distX + distY);
                    var ratioF = curF.score / distY;
                    if (distF < dist) {
                        dist = distF;
                        x = curF.x;
                        y = curF.y;
                        hasTarget = true;
                    }
                }
            }

            if (curE.carry > 100) {
                x = e_antHill.x;
                y = e_antHill.y;
            }

            if ((x > curE.x + 5) && hasTarget) {
                curE.x += curE.speed;
            }
            else if ((x < curE.x - 5) && hasTarget) {
                curE.x -= curE.speed;
            }
            if ((y > curE.y + 5) && hasTarget) {
                curE.y += curE.speed;
            }
            if ((y < curE.y - 5) && hasTarget) {
                curE.y -= curE.speed;
            }

            for (var i = 0; i < object_arr.length; i++) {
                var curF = object_arr[i];
                if (curF instanceof food) {
                    var radius = (curF.size / 2) + 2;
                    if (curE.x > curF.x - radius && curE.x < curF.x + radius &&
                        curE.y > curF.y - radius && curE.y < curF.y + radius) {
                        curE.carry += Math.floor(curF.score);
                        object_arr.splice(i, 1);
                        object_arr.push(create_food());
                        hasTarget = false;
                    }
                }
            }

            var radius = e_antHill.size / 2 + 2;
            if (curE.x > e_antHill.x - radius && curE.x < e_antHill.x + radius &&
                curE.y > e_antHill.y - radius && curE.y < e_antHill.y + radius) {
                e_antHill.score += curE.carry;
                curE.carry = 0;
            }

            radius = p_antHill.size / 2 + 2;
            if (curE.x > p_antHill.x - radius && curE.x < p_antHill.x + radius &&
                curE.y > p_antHill.y - radius && curE.y < p_antHill.y + radius) {
                curE.inEnemyTerr = true;
                var curCarry = ant.carry;
                if (!curE.gavePoints) {
                    p_antHill.score += Math.round((curE.carry / 4) * 3);
                    curE.carry = Math.round(curE.carry / 4);
                    curE.gavePoints = true;
                }
            }
            else {
                curE.inEnemyTerr = false;
                curE.gavePoints = false;
            }

            if (curE.carry == 0) {
                curE.speed = 5;
            }
            if (curE.speed >= 0.5 ) {
                curE.speed = (5 - curE.carry / 100);
            }
            if (curE.speed < 0.5 ) {
                curE.speed = 0.5;
            }
            if (count < 4) {
                curE.speed = 2;
            }
        }

        //AntHill Functions
        function draw_antHill(x,y,size, color,side)
        {
            draw_Square(x, y, size, "brown", h_ctx);
        
            h_ctx.fillStyle = color;
            var text;

            if(side == 0)
            {
                text = "Score: " + p_antHill.score;
            }
            if (side == 1) {
                text = "Score: " + e_antHill.score;
            }
            h_ctx.font = o_font;
            if (x < w / 2) {
                if (y < h / 2) {
                    h_ctx.fillText(text, x - (size / 2 + 2), y + (size / 2 + 10));
                }
                else if (y > h / 2) {
                    h_ctx.fillText(text, x - (size / 2 + 2), y - (size / 2 + 5));
                }
            }
            else if (x > w / 2) {
                if (y < h / 2) {
                    h_ctx.fillText(text, x - (size / 2 + 2), y + (size / 2 + 10));
                }
                else if (y > h / 2) {
                    h_ctx.fillText(text, x - (size / 2 + 2), y - (size / 2 + 5));
                }
            }
        }

        //Food functions
        function create_food() {
            var l_size = Math.round(Math.random() * 15 + 7);
            return new food(Math.round(Math.random() * (w-10) + 10),
                Math.round(Math.random() * (h-10) + 10),
                l_size,
                Math.round(l_size*(l_size/2)));
        }

        food.prototype.draw = function() {
            var curF = this;
            draw_Square(curF.x, curF.y, curF.size, "Orange", f_ctx);
            a_ctx.fillStyle = "black";
            var foodVal = "V: " + curF.score;
            a_ctx.fillText(foodVal, curF.x - (curF.size / 2 + 2), curF.y - (curF.size / 2 + 2));
        }

        food.prototype.action = function () {}

        //gets key press for ant control
        $(document).keydown(function (e) {
            var key = (e.keyCode) ? e.keyCode : e.which;

            if (key == "37") {
                e.preventDefault();
                isLeftKey = true;
            }
            if (key == "38") {
                e.preventDefault();
                isUpKey = true;
            }
            if (key == "39") {
                e.preventDefault();
                isRightKey = true;
            }
            if (key == "40") {
                e.preventDefault();
                isDownKey = true;
            }
            if( key == "80"){
                e.preventDefault();
                if( count < 60){
                    isPlaying = !isPlaying;
                    if( gametime){
                        stopTime();
                    }
                    else{
                        startTime();
                    }
                }
            }
        })

        $(document).keyup(function (e) {
            var key = (e.keyCode) ? e.keyCode : e.which;

            if (key == "37") {
                e.preventDefault();
                isLeftKey = false;
            }
            if (key == "38") {
                e.preventDefault();
                isUpKey = false;
            }
            if (key == "39") {
                e.preventDefault();
                isRightKey = false;
            }
            if (key == "40") {
                e.preventDefault();
                isDownKey = false;
            }
            if( key == "80"){
                e.preventDefault();
            }

        })
    
})